-- Migration: 00001_create_incidents.sql
-- Create the incidents table for Waze/Tesla style reporting

CREATE TABLE IF NOT EXISTS public.incidents (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('radar', 'danger', 'police', 'traffic')),
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  desc_text TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Turn on Row Level Security
ALTER TABLE public.incidents ENABLE ROW LEVEL SECURITY;

-- Allow anonymous read access
CREATE POLICY "Allow public read access to incidents"
ON public.incidents
FOR SELECT
TO public
USING (true);

-- Allow anonymous insert access (for reports)
CREATE POLICY "Allow public insert access to incidents"
ON public.incidents
FOR INSERT
TO public
WITH CHECK (true);
