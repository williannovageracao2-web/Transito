import React, { useState, useEffect } from 'react';
import { TeslaMap } from './components/TeslaMap';
import { BottomBar, TopOverlay, NavigationPanel, MusicPlayerOverlay, MapControls, FullScreenAppOverlay, RadarAlertOverlay } from './components/TeslaOverlay';
import { LeftSidebar } from './components/LeftSidebar';
import { Camera, AlertTriangle, Car, ShieldAlert } from 'lucide-react';
import { useAppStore } from './store';
import { supabase } from './lib/supabase';

export default function App() {
  const [navTarget, setNavTarget] = useState<string | null>(null);
  const [showReportMenu, setShowReportMenu] = useState(false);
  const currentPosition = useAppStore(state => state.currentPosition);
  const setGlobalIncidents = useAppStore(state => state.setGlobalIncidents);
  const addGlobalIncident = useAppStore(state => state.addGlobalIncident);

  useEffect(() => {
    // Fetch initial incidents
    const fetchIncidents = async () => {
      if (!supabase) return; // Skip if no supabase configuration
      try {
        const { data, error } = await supabase.from('incidents').select('*');
        if (error) {
          console.error("Error fetching incidents:", error);
          return;
        }
        if (data && !error) {
          setGlobalIncidents(data.map(d => ({
             id: d.id,
             type: d.type as any,
             lat: d.lat,
             lng: d.lng,
             desc: d.desc_text
          })));
        }
      } catch (err) {
        console.error("Unknown error fetching incidents:", err);
      }
    };
    fetchIncidents();

    if (!supabase) return;
    
    // Subscribe to new incidents
    const subscription = supabase
      .channel('public:incidents')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'incidents' }, payload => {
        const d = payload.new as any;
        addGlobalIncident({
           id: d.id,
           type: d.type as any,
           lat: d.lat,
           lng: d.lng,
           desc: d.desc_text
        });
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [setGlobalIncidents, addGlobalIncident]);

  const handleReport = async (type: 'radar' | 'danger' | 'police' | 'traffic', desc: string) => {
    setShowReportMenu(false);
    if (!currentPosition) {
       console.error("No current position available to report incident.");
       alert("Sua localização ainda não foi carregada.");
       return;
    }

    // Fast local optimistic update
    const tempId = Math.random().toString();
    addGlobalIncident({
      id: tempId,
      type,
      lat: currentPosition.lat,
      lng: currentPosition.lng,
      desc
    });

    if (supabase) {
      try {
        const { error } = await supabase.from('incidents').insert({
          type,
          lat: currentPosition.lat,
          lng: currentPosition.lng,
          desc_text: desc
        });
        if (error) {
          console.error("Error inserting incident:", error);
          alert("Erro ao salvar no Supabase: " + error.message);
        }
      } catch (err: any) {
        console.error("Unknown error inserting incident:", err);
        alert("Erro desconhecido ao salvar no Supabase: " + err?.message);
      }
    } else {
      alert("Configuração do Supabase não encontrada! As credenciais não foram definidas corretamente.");
    }
  };

  return (
    <div className="flex h-screen w-full bg-black overflow-hidden font-sans text-white select-none">
      {/* 
        Container for the app main content area, ignoring bottom bar 
      */}
      <div className="flex flex-1 w-full relative pb-[68px]">
        
        {/* Left Sidebar (Speedometer + Car Model) */}
        <LeftSidebar />

        {/* Right side (Map + Media + Nav Overlay) */}
        <div className="flex-1 relative overflow-hidden bg-[#111]">
          <TopOverlay />
          <RadarAlertOverlay />
          
          <div className="absolute inset-x-0 bottom-0 top-10 pointer-events-auto overflow-hidden">
            <TeslaMap navTarget={navTarget} />
          </div>
          
          <NavigationPanel onNavigate={(target) => setNavTarget(target)} onCancel={() => setNavTarget(null)} />
          
          <MusicPlayerOverlay />
          
          <MapControls onReport={() => setShowReportMenu(!showReportMenu)} />

          <FullScreenAppOverlay />

          {/* Waze style report menu overlay */}
          {showReportMenu && (
            <div className="absolute left-1/2 -translate-x-1/2 md:left-auto md:translate-x-0 md:right-[90px] top-1/2 -translate-y-1/2 bg-[#121212]/95 backdrop-blur-xl border border-white/10 rounded-2xl p-4 shadow-2xl flex flex-col gap-4 z-[1000] w-64 animate-in fade-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                 <h3 className="font-semibold text-[16px]">Report</h3>
                 <button onClick={() => setShowReportMenu(false)} className="text-gray-400 hover:text-white pb-1">
                   ✕
                 </button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button className="flex flex-col items-center gap-2 p-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/20 transition-colors" onClick={() => handleReport('radar', 'Radar de velocidade')}>
                  <Camera className="w-6 h-6" />
                  <span className="text-[12px] font-medium">Radar</span>
                </button>
                <button className="flex flex-col items-center gap-2 p-3 rounded-xl bg-orange-500/10 hover:bg-orange-500/20 text-orange-500 border border-orange-500/20 transition-colors" onClick={() => handleReport('danger', 'Perigo na via')}>
                  <AlertTriangle className="w-6 h-6" />
                  <span className="text-[12px] font-medium">Perigo</span>
                </button>
                <button className="flex flex-col items-center gap-2 p-3 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-500 border border-blue-500/20 transition-colors" onClick={() => handleReport('traffic', 'Trânsito intenso')}>
                  <Car className="w-6 h-6" />
                  <span className="text-[12px] font-medium">Trânsito</span>
                </button>
                <button className="flex flex-col items-center gap-2 p-3 rounded-xl bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-500 border border-yellow-500/20 transition-colors" onClick={() => handleReport('police', 'Polícia reportada')}>
                  <ShieldAlert className="w-6 h-6" />
                  <span className="text-[12px] font-medium">Polícia</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Fixed Full Width Bottom Taskbar */}
      <div className="fixed bottom-0 w-full z-50">
         <BottomBar />
      </div>
    </div>
  );
}
