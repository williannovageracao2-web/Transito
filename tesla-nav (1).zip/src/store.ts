import { create } from 'zustand';

export type Gear = 'P' | 'R' | 'N' | 'D';
export type DrivingMode = 'Chill' | 'Standard' | 'Sport';

interface RouteStats {
  distance: string;
  duration: string;
  eta: string;
  rawDurationSec: number;
}

interface Incident {
  id: string;
  type: 'radar' | 'danger' | 'police' | 'traffic';
  lat: number;
  lng: number;
  desc: string;
}

interface AppState {
  gear: Gear;
  setGear: (gear: Gear) => void;
  
  drivingMode: DrivingMode;
  setDrivingMode: (mode: DrivingMode) => void;

  climateTemp: number;
  setClimateTemp: (temp: number) => void;

  activeApp: 'map' | 'music' | 'phone' | 'climate' | 'car' | null;
  setActiveApp: (app: 'map' | 'music' | 'phone' | 'climate' | 'car' | null) => void;

  navTargetString: string | null;
  routeGeometry: [number, number][] | null;
  routeStats: RouteStats | null;
  routeIncidents: Incident[];
  globalIncidents: Incident[];
  setRouteInfo: (target: string | null, geom: [number, number][] | null, stats: RouteStats | null, incidents: Incident[]) => void;
  setGlobalIncidents: (incidents: Incident[]) => void;
  addGlobalIncident: (incident: Incident) => void;


  alertDistance: number;
  setAlertDistance: (dist: number) => void;

  activeAlert: Incident | null;
  setActiveAlert: (alert: Incident | null) => void;

  currentPosition: { lat: number; lng: number } | null;
  setCurrentPosition: (pos: { lat: number; lng: number } | null) => void;

  speed: number;
  setSpeed: (speed: number) => void;
}

export const useAppStore = create<AppState>((set) => ({
  gear: 'P',
  setGear: (gear) => set({ gear }),

  drivingMode: 'Standard',
  setDrivingMode: (mode) => set({ drivingMode: mode }),

  climateTemp: 21,
  setClimateTemp: (climateTemp) => set({ climateTemp }),

  activeApp: null,
  setActiveApp: (app) => set((state) => ({ activeApp: state.activeApp === app ? null : app })),

  navTargetString: null,
  routeGeometry: null,
  routeStats: null,
  routeIncidents: [],
  globalIncidents: [],
  setRouteInfo: (navTargetString, routeGeometry, routeStats, routeIncidents) => set({ navTargetString, routeGeometry, routeStats, routeIncidents }),
  setGlobalIncidents: (incidents) => set({ globalIncidents: incidents }),
  addGlobalIncident: (incident) => set((state) => ({ globalIncidents: [...state.globalIncidents, incident] })),


  alertDistance: 500, // default 500 meters
  setAlertDistance: (dist) => set({ alertDistance: dist }),

  activeAlert: null,
  setActiveAlert: (alert) => set({ activeAlert: alert }),

  currentPosition: null,
  setCurrentPosition: (pos) => set({ currentPosition: pos }),

  speed: 0,
  setSpeed: (speed) => set({ speed }),
}));
