import { Car, Fan, Disc3, Phone, Camera, CloudRain, Volume2, Divide as Navigation, BatteryFull, Bluetooth, Signal, Search, Mic, Menu, AlertTriangle, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useAppStore } from '../store';

export function BottomBar() {
  const [time, setTime] = useState("");
  const setClimateTemp = useAppStore(state => state.setClimateTemp);
  const climateTemp = useAppStore(state => state.climateTemp);
  const activeApp = useAppStore(state => state.activeApp);
  const setActiveApp = useAppStore(state => state.setActiveApp);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-[68px] bg-black flex items-center justify-between px-3 md:px-8 border-t border-white/5 shrink-0 z-[2000] text-white select-none relative overflow-x-auto no-scrollbar">
      {/* Left items */}
      <div className="flex items-center gap-4 md:gap-8 shrink-0">
        <div className="text-center shrink-0">
          <div className="text-[20px] font-light hover:text-white transition-colors cursor-pointer" onClick={() => setActiveApp('climate')}>{climateTemp}°</div>
          <div className="w-6 h-1 bg-red-500 rounded-full mx-auto mt-1 cursor-pointer"></div>
        </div>
        <button className="hidden md:flex items-center justify-center hover:bg-white/10 w-12 h-12 rounded-xl transition-colors shrink-0">
          <div className="w-6 h-6 flex space-x-1 outline outline-1 outline-white/30 p-1 rounded">
             <div className="w-[3px] h-full bg-red-500 rounded" />
             <div className="w-[3px] h-full bg-red-500 rounded" />
             <div className="w-[3px] h-full bg-red-500 rounded" />
          </div>
        </button>
        <button onClick={() => setActiveApp('climate')} className={`flex flex-col items-center justify-center w-12 h-12 rounded-xl transition-colors shrink-0 ${activeApp === 'climate' ? 'bg-white/20 text-white' : 'hover:bg-white/10 text-gray-500 hover:text-white'}`}>
          <Fan className="w-6 h-6" />
        </button>
      </div>

      {/* Center Apps */}
      <div className="flex items-center gap-6 md:gap-10 opacity-70 shrink-0 px-4 md:px-0 mx-auto">
        <button onClick={() => setActiveApp('car')} className={`flex flex-col items-center justify-center transition-colors shrink-0 ${activeApp === 'car' ? 'text-blue-500 scale-110' : 'hover:text-white'}`}>
           <Car className="w-6 h-6" />
        </button>
        <button onClick={() => setActiveApp('music')} className={`flex flex-col items-center justify-center transition-colors shrink-0 ${activeApp === 'music' ? 'text-blue-500 scale-110' : 'hover:text-white'}`}>
           <Disc3 className="w-6 h-6" />
        </button>
        <button onClick={() => setActiveApp('map')} className={`flex flex-col items-center justify-center transition-colors shrink-0 ${activeApp === 'map' ? 'text-blue-500 scale-110' : 'hover:text-white'}`}>
           <Navigation className="w-6 h-6" />
        </button>
        <button onClick={() => setActiveApp('phone')} className={`flex flex-col items-center justify-center transition-colors shrink-0 ${activeApp === 'phone' ? 'text-blue-500 scale-110' : 'hover:text-white'}`}>
           <Phone className="w-6 h-6" />
        </button>
        <button className="flex flex-col items-center justify-center hover:text-white transition-colors shrink-0">
           <Menu className="w-6 h-6" />
        </button>
      </div>

      {/* Right items */}
      <div className="flex items-center gap-4 md:gap-8 shrink-0">
        <div className="hidden md:flex items-center justify-center px-2 h-12 gap-4 shrink-0">
          <Volume2 className="w-5 h-5 text-gray-500" />
          <div className="w-[100px] h-1 bg-white/20 rounded-full relative cursor-pointer">
            <div className="absolute left-0 top-0 h-full w-[60%] bg-white rounded-full"></div>
          </div>
        </div>
        <button className="hidden sm:flex items-center justify-center hover:bg-white/10 w-12 h-12 rounded-xl transition-colors shrink-0">
          <div className="w-6 h-6 flex space-x-1 outline outline-1 outline-white/30 p-1 rounded">
             <div className="w-[3px] h-full bg-red-500 rounded" />
             <div className="w-[3px] h-full bg-red-500 rounded" />
             <div className="w-[3px] h-full bg-red-500 rounded" />
          </div>
        </button>
        <div className="text-center shrink-0">
          <div className="text-[20px] font-light hover:text-white transition-colors cursor-pointer" onClick={() => setActiveApp('climate')}>{climateTemp}°</div>
          <div className="w-6 h-1 bg-blue-500 rounded-full mx-auto mt-1 cursor-pointer"></div>
        </div>
      </div>
    </div>
  );
}

export function TopOverlay() {
  const [time, setTime] = useState("");
  const climateTemp = useAppStore(state => state.climateTemp);
  const speed = useAppStore(state => state.speed);

  useEffect(() => {
    const now = new Date();
    setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    
    const interval = setInterval(() => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-10 px-4 md:px-6 flex justify-between items-center bg-[#000000] border-b border-white/5 text-[12px] md:text-[14px] font-medium shrink-0 z-[1000] text-white/90 relative">
      <div className="flex items-center gap-3 md:gap-4">
         <span>{time || "00:00"}</span>
         <span className="text-gray-400">{climateTemp}°C Exterior</span>
      </div>
      
      {/* Mobile Speedometer */}
      <div className="md:hidden absolute left-1/2 -translate-x-1/2 flex items-baseline gap-1 text-white">
        <span className="text-[22px] font-semibold leading-none">{speed}</span>
        <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">km/h</span>
      </div>

      <div className="flex items-center gap-3 md:gap-4 text-gray-400">
        <Bluetooth className="w-4 h-4" />
        <Signal className="w-4 h-4" />
        <span className="text-white hidden sm:inline">Victor's Model X</span>
      </div>
    </div>
  );
}

export function NavigationPanel({ onNavigate, onCancel }: { onNavigate: (target: string) => void, onCancel?: () => void }) {
  const [val, setVal] = useState("");
  const [destination, setDestination] = useState("");
  const [isNavigating, setIsNavigating] = useState(false);
  const routeStats = useAppStore(state => state.routeStats);

  const startNav = (target: string) => {
    setDestination(target);
    setIsNavigating(true);
    onNavigate(target);
  };

  const stopNav = () => {
    setIsNavigating(false);
    setVal("");
    setDestination("");
    if (onCancel) onCancel();
  };

  if (isNavigating) {
    return (
      <div className="absolute top-6 left-6 w-[360px] max-w-[calc(100vw-48px)] z-[1000] flex flex-col gap-4 pointer-events-none">
        
        {/* Floating Nav Controls */}
        <div className="bg-[#121212]/95 backdrop-blur-xl p-4 rounded-2xl shadow-2xl border border-blue-500/30 pointer-events-auto">
          <div className="flex gap-4 items-center">
            <div className="w-14 h-14 bg-blue-600 rounded-xl flex items-center justify-center shrink-0">
               <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 10l7-7m0 0l7 7m-7-7v18"></path></svg>
            </div>
            <div className="flex-1 overflow-hidden">
              <div className="text-blue-400 text-[13px] font-bold uppercase tracking-wider">Indo para</div>
              <div className="text-white font-semibold text-[18px] leading-tight mt-0.5 truncate pr-2">{destination}</div>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-white/10 flex justify-between text-[14px]">
            <span className="text-gray-400">Chegada em <span className="text-white font-medium">{routeStats ? routeStats.eta : "..."}</span></span>
            <span className="text-gray-400">Dist. <span className="text-white font-medium">{routeStats ? routeStats.distance : "..."}</span></span>
          </div>
        </div>
        
        {/* Navigation Stats */}
        <div className="bg-[#121212]/95 backdrop-blur-xl shadow-2xl rounded-2xl p-5 border border-white/10 text-white flex justify-between items-center pointer-events-auto">
           <div className="flex flex-col">
             <span className="text-[40px] leading-none font-light tracking-tighter text-green-400">
                {routeStats ? routeStats.duration.split(' ')[0] : "--"}
                <span className="text-[18px] text-green-400/70 font-normal ml-1">min</span>
             </span>
             <span className="text-neutral-400 text-[14px] mt-1">{routeStats ? routeStats.distance : "-- km"} • {routeStats ? routeStats.eta : "--:--"}</span>
           </div>
           <button onClick={stopNav} className="bg-red-500/20 hover:bg-red-500 transition-colors text-red-500 hover:text-white px-6 py-3 rounded-xl font-medium tracking-wide border border-red-500/30">
             Encerrar
           </button>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute top-6 left-6 w-[360px] max-w-[calc(100vw-48px)] z-[1000] flex flex-col gap-4 pointer-events-none">
      <div className="bg-[#121212]/95 backdrop-blur-2xl rounded-2xl shadow-2xl border border-white/10 flex flex-col text-white overflow-hidden pointer-events-auto transition-all relative">
        <div className="p-4 border-b border-white/5 flex flex-col gap-3 relative z-10">
          <div className="flex items-center gap-3 w-full">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-500 ml-1 shrink-0 shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
            <div className="flex-1 bg-white/5 px-3 py-2.5 rounded-lg text-[14px] text-blue-400 font-medium border border-white/5 truncate">
              De: Meu Local Atual
            </div>
          </div>
          <div className="absolute left-[24px] top-[42px] bottom-[auto] h-4 w-px bg-white/20" />
          <div className="flex items-center gap-3 w-full relative">
            <div className="w-2.5 h-2.5 rounded-full border-[2.5px] border-red-500 bg-transparent ml-1 shrink-0 shadow-[0_0_8px_rgba(239,68,68,0.6)]" />
            <div className="flex-1 flex items-center bg-[#1a1a1a] border border-white/10 px-3 py-2.5 rounded-lg focus-within:border-white/30 transition-colors relative">
              <input 
                type="text"
                placeholder="Para onde?"
                value={val}
                onChange={e => setVal(e.target.value)}
                onKeyDown={(e) => {
                   if (e.key === 'Enter' && val) startNav(val);
                }}
                className="flex-1 bg-transparent text-[15px] outline-none placeholder-gray-500 font-medium"
              />
              <Mic className="w-[16px] h-[16px] text-gray-400 hover:text-white cursor-pointer shrink-0 transition-colors" />
            </div>
          </div>
        </div>
        <div className="flex flex-col py-2">
          <button className="flex items-center px-4 py-3 hover:bg-white/5 transition-colors text-left group" onClick={() => startNav('Casa')}>
            <div className="w-10 h-10 rounded-full bg-blue-600/20 text-blue-500 flex items-center justify-center mr-4 group-hover:bg-blue-600/30 transition-colors shrink-0">
              <Car className="w-5 h-5" />
            </div>
            <div className="flex flex-col flex-1">
              <span className="text-[15px] font-medium tracking-tight">Casa</span>
              <span className="text-[13px] text-gray-400 mt-0.5">Rua Principal, 123</span>
            </div>
          </button>
          <button className="flex items-center px-4 py-3 hover:bg-white/5 transition-colors text-left group" onClick={() => startNav('Trabalho')}>
            <div className="w-10 h-10 rounded-full bg-white/10 text-gray-300 flex items-center justify-center mr-4 group-hover:bg-white/20 transition-colors shrink-0">
              <Search className="w-5 h-5" />
            </div>
            <div className="flex flex-col flex-1">
              <span className="text-[15px] font-medium tracking-tight">Trabalho</span>
              <span className="text-[13px] text-gray-400 mt-0.5">Av. Empresarial, 456</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}

export function MapControls({ onReport }: { onReport?: () => void }) {
  return (
    <div className="absolute right-6 top-1/2 -translate-y-1/2 flex flex-col gap-4 z-[1000] pointer-events-auto">
      <div className="bg-[#121212]/90 backdrop-blur-md rounded-xl border border-white/10 shadow-2xl flex flex-col overflow-hidden">
        <button className="w-12 h-12 flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-colors border-b border-white/10">
          <Navigation className="w-5 h-5" />
        </button>
        <button className="w-12 h-12 flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-colors border-b border-white/10">
          <span className="text-2xl font-light leading-none mb-1">+</span>
        </button>
        <button className="w-12 h-12 flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-colors">
          <span className="text-2xl font-light leading-none mb-1">-</span>
        </button>
      </div>
      <button 
        onClick={onReport}
        className="w-14 h-14 bg-orange-500 hover:bg-orange-400 text-white rounded-full flex items-center justify-center shadow-[0_4px_20px_rgba(249,115,22,0.4)] border border-orange-400 mt-4 transition-transform hover:scale-105"
      >
        <AlertTriangle className="w-6 h-6" />
      </button>
    </div>
  );
}

export function MusicPlayerOverlay() {
  const activeApp = useAppStore(state => state.activeApp);
  if (activeApp === 'music') return null; // We'll handle full app elsewhere optionally
  
  return (
    <div className="absolute bottom-6 left-4 md:left-6 right-20 md:right-auto md:w-[300px] bg-[#121212]/90 backdrop-blur-xl p-3 rounded-2xl border border-white/10 flex items-center gap-3 md:gap-4 pointer-events-auto shadow-2xl z-[1000] transition-all hover:bg-[#1a1a1a]/95">
      <div className="w-12 h-12 md:w-14 md:h-14 bg-gradient-to-br from-red-600 to-orange-400 rounded-xl shrink-0 shadow-inner flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
      </div>
      <div className="flex-1 overflow-hidden">
        <div className="text-[15px] font-medium truncate text-white">Blinding Lights</div>
        <div className="text-[13px] text-gray-400 truncate">The Weeknd</div>
      </div>
      <div className="flex gap-2 text-gray-400 shrink-0 pr-2">
         <button className="hover:text-white transition-colors"><Disc3 className="w-6 h-6" /></button>
      </div>
    </div>
  );
}

export function FullScreenAppOverlay() {
  const activeApp = useAppStore(state => state.activeApp);
  const setActiveApp = useAppStore(state => state.setActiveApp);
  const climateTemp = useAppStore(state => state.climateTemp);
  const setClimateTemp = useAppStore(state => state.setClimateTemp);
  const alertDistance = useAppStore(state => state.alertDistance);
  const setAlertDistance = useAppStore(state => state.setAlertDistance);

  if (!activeApp || activeApp === 'map') return null;

  return (
    <div className="absolute inset-0 z-[1000] bg-black/40 backdrop-blur-md flex items-center justify-center p-4 md:p-12 pointer-events-auto animate-in fade-in duration-200">
      <div className="w-full max-w-4xl h-[600px] max-h-[85vh] bg-[#0c0c0c] border border-white/10 rounded-2xl md:rounded-[32px] shadow-2xl flex flex-col overflow-hidden relative shadow-[0_0_80px_rgba(0,0,0,0.8)]">
        
        {/* Header */}
        <div className="h-14 md:h-16 border-b border-white/5 flex items-center px-4 md:px-8 shrink-0 relative bg-[#121212]">
          <h2 className="text-lg md:text-xl font-medium tracking-tight uppercase text-gray-300">
             {activeApp === 'music' ? 'Spotify' : activeApp === 'car' ? 'Veículo' : activeApp === 'climate' ? 'Climatização' : 'Telefone'}
          </h2>
          <button onClick={() => setActiveApp(null)} className="absolute right-4 md:right-6 p-2 rounded-full hover:bg-white/10 transition-colors">
            <X className="w-5 h-5 md:w-6 md:h-6 text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6 md:p-12 relative flex items-center justify-center">
          {activeApp === 'climate' && (
            <div className="flex flex-col items-center gap-8 md:gap-12">
               <div className="text-center">
                 <div className="text-gray-400 font-medium tracking-wider uppercase mb-2 md:mb-4 text-xs md:text-sm">Temperatura</div>
                 <div className="text-[80px] md:text-[120px] font-light leading-none tracking-tighter text-white">{climateTemp}°</div>
               </div>
               <div className="flex items-center gap-6 md:gap-8">
                 <button onClick={() => setClimateTemp(climateTemp - 1)} className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-3xl md:text-4xl font-light hover:bg-white/10 active:scale-95 transition-all text-blue-400">-</button>
                 <button onClick={() => setClimateTemp(climateTemp + 1)} className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-3xl md:text-4xl font-light hover:bg-white/10 active:scale-95 transition-all text-red-400">+</button>
               </div>
            </div>
          )}

          {activeApp === 'phone' && (
             <div className="w-full max-w-sm flex flex-col gap-6">
                <div className="text-center mb-4">
                  <div className="text-white text-2xl md:text-3xl font-light tracking-tight mb-2">João Silva</div>
                  <div className="text-gray-400 text-base md:text-lg">Chamando...</div>
                </div>
                <div className="flex justify-center gap-6">
                  <button className="w-14 h-14 md:w-16 md:h-16 rounded-full bg-red-600 flex items-center justify-center shadow-lg hover:bg-red-500 transition-colors">
                    <Phone className="w-6 h-6 md:w-8 md:h-8 text-white rotate-[135deg]" />
                  </button>
                </div>
             </div>
          )}
          
          {activeApp === 'car' && (
             <div className="w-full h-full flex flex-col pt-4 overflow-y-auto">
                <div className="flex flex-col items-center justify-center gap-6 mb-8 md:mb-12">
                  <Car className="w-24 h-24 md:w-32 md:h-32 text-gray-700 mx-auto" />
                  <div className="flex flex-col md:flex-row gap-3 md:gap-4 w-full md:w-auto px-4 md:px-0">
                    <button className="w-full md:w-auto px-8 py-3 rounded-full bg-white/10 border border-white/20 text-white font-medium hover:bg-white/20 transition-colors">Abrir Porta-mala</button>
                    <button className="w-full md:w-auto px-8 py-3 rounded-full bg-white/10 border border-white/20 text-white font-medium hover:bg-white/20 transition-colors">Destravar Portas</button>
                  </div>
                </div>

                <div className="max-w-2xl mx-auto w-full space-y-8 px-4 md:px-0">
                  <h3 className="text-lg md:text-xl font-medium text-white/80 border-b border-white/10 pb-4">Navegação e Alertas</h3>
                  
                  <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 md:gap-0">
                     <div>
                       <div className="text-base md:text-lg text-white font-medium">Distância de Alerta de Radar</div>
                       <div className="text-gray-400 text-xs md:text-sm mt-1">Aciona o aviso visual e sonoro antes de se aproximar de radares ou perigos.</div>
                     </div>
                     <div className="flex flex-wrap md:flex-nowrap items-center gap-1 bg-white/5 rounded-lg p-1 border border-white/10 w-full md:w-auto">
                        {[200, 500, 1000].map(dist => (
                          <button 
                            key={dist}
                            onClick={() => setAlertDistance(dist)}
                            className={`flex-1 md:flex-none px-2 md:px-4 py-2 rounded-md font-medium text-xs md:text-sm transition-colors ${alertDistance === dist ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'}`}
                          >
                            {dist >= 1000 ? `${dist/1000} km` : `${dist} m`}
                          </button>
                        ))}
                     </div>
                  </div>
                  
                  <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 md:gap-0">
                     <div>
                       <div className="text-base md:text-lg text-white font-medium">Testar Alerta Sonoro/Visual</div>
                       <div className="text-gray-400 text-xs md:text-sm mt-1">Simular um alerta de radar na tela.</div>
                     </div>
                     <button
                        onClick={() => {
                           const alert = { id: 'test', type: 'radar', lat: 0, lng: 0, desc: 'Radar 60 km/h (Teste)' };
                           useAppStore.getState().setActiveAlert(alert as any);
                           setTimeout(() => useAppStore.getState().setActiveAlert(null), 5000);
                           try {
                             const speech = new SpeechSynthesisUtterance(`Atenção: Radar 60 quilômetros por hora`);
                             speech.lang = 'pt-BR';
                             speech.rate = 1.1;
                             window.speechSynthesis.speak(speech);
                           } catch(e) {}
                        }}
                        className="w-full md:w-auto px-6 py-2 bg-white/10 hover:bg-white/20 border border-white/20 rounded-md font-medium transition-colors text-white"
                     >
                       Testar
                     </button>
                  </div>
                </div>
             </div>
          )}

          {activeApp === 'music' && (
             <div className="w-full flex md:flex-row flex-col items-center gap-8 md:gap-12 max-w-2xl px-4 md:px-0">
               <div className="w-48 h-48 md:w-64 md:h-64 bg-gradient-to-br from-red-600 to-orange-400 rounded-2xl md:rounded-3xl shadow-2xl flex-shrink-0" />
               <div className="flex flex-col flex-1 w-full text-center md:text-left">
                 <h3 className="text-3xl md:text-5xl font-bold tracking-tight text-white mb-1 md:mb-2 truncate">Blinding Lights</h3>
                 <p className="text-lg md:text-2xl text-gray-400 mb-8 md:mb-12">The Weeknd</p>
                 <div className="w-full h-2 bg-white/20 rounded-full mb-6 relative">
                    <div className="absolute left-0 top-0 bottom-0 w-1/3 bg-white rounded-full" />
                 </div>
                 <div className="flex justify-between md:justify-start items-center md:gap-8 px-4 md:px-0">
                   <button className="text-gray-400 hover:text-white"><Navigation className="w-6 h-6 md:w-8 md:h-8 -rotate-90" /></button>
                   <button className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-white text-black flex items-center justify-center">
                     <span className="w-5 h-5 md:w-6 md:h-6 bg-black rounded-sm" />
                   </button>
                   <button className="text-gray-400 hover:text-white"><Navigation className="w-6 h-6 md:w-8 md:h-8 rotate-90" /></button>
                 </div>
               </div>
             </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function RadarAlertOverlay() {
  const activeAlert = useAppStore(state => state.activeAlert);

  if (!activeAlert) return null;

  const isRadar = activeAlert.type === 'radar';
  const bgColor = isRadar ? 'bg-red-500/95' : 'bg-orange-500/95';
  const iconColor = isRadar ? 'text-red-500' : 'text-orange-500';

  return (
    <div className="absolute top-20 left-1/2 -translate-x-1/2 z-[1000] animate-in slide-in-from-top-10 fade-in duration-300 pointer-events-none shadow-[0_20px_60px_rgba(0,0,0,0.6)] w-[calc(100vw-32px)] md:w-auto">
       <div className={`${bgColor} backdrop-blur-xl border border-white/20 rounded-2xl flex items-center p-3 md:p-4 gap-3 md:gap-5 w-full md:w-[420px]`}>
          <div className="w-12 h-12 md:w-16 md:h-16 bg-white rounded-full flex items-center justify-center shrink-0 shadow-inner">
             {isRadar ? <Camera className={`w-6 h-6 md:w-8 md:h-8 ${iconColor}`} /> : <AlertTriangle className={`w-6 h-6 md:w-8 md:h-8 ${iconColor}`} />}
          </div>
          <div className="text-white flex-1 overflow-hidden">
             <div className="text-lg md:text-xl font-bold tracking-tight leading-tight mb-1 uppercase">
               Alerta
             </div>
             <div className="text-white font-medium text-base md:text-lg flex items-center gap-2 truncate">
               {activeAlert.desc}
             </div>
          </div>
       </div>
    </div>
  );
}
