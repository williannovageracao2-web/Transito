import { useState, useEffect } from 'react';
import { Leaf, Zap, Gauge } from 'lucide-react';
import { useAppStore, Gear } from '../store';

export function LeftSidebar() {
  const [turnSignal, setTurnSignal] = useState<'left' | 'right' | 'none'>('none');
  const drivingMode = useAppStore(state => state.drivingMode);
  const setDrivingMode = useAppStore(state => state.setDrivingMode);
  const gear = useAppStore(state => state.gear);
  const setGear = useAppStore(state => state.setGear);
  const speed = useAppStore(state => state.speed);
  const setSpeed = useAppStore(state => state.setSpeed);

  useEffect(() => {
    if (!navigator.geolocation) return;

    let watchId: number;
    let lastSpeedUpdate = 0;

    const startTracking = () => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          if (pos.coords.speed != null && gear === 'D') {
            setSpeed(Math.round(pos.coords.speed * 3.6));
          } else if (gear === 'P') {
            setSpeed(0);
          }
        },
        (err) => console.warn(err),
        { enableHighAccuracy: true }
      );
      
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const now = Date.now();
          if (now - lastSpeedUpdate < 1000) return;
          lastSpeedUpdate = now;

          if (gear === 'P') {
            setSpeed(0);
          } else if (pos.coords.speed != null && gear === 'D') {
             // Mock some speed if no real movement but in drive
             let s = Math.round(pos.coords.speed * 3.6);
             if (s === 0) s = Math.floor(Math.random() * 5);
             setSpeed(s);
          }
        },
        (err) => console.warn(err),
        { enableHighAccuracy: true, maximumAge: 2000 }
      );
    };
    
    startTracking();
    return () => navigator.geolocation.clearWatch(watchId);
  }, [gear]);

  const gears: Gear[] = ['P', 'R', 'N', 'D'];

  return (
    <div className="hidden md:flex w-[340px] bg-[#111111] flex-col border-r border-white/5 shrink-0 z-10 relative overflow-y-auto pb-[90px]">
      <div className="p-6 flex flex-col items-center h-full">
        {/* Speedometer Area */}
        <div className="text-center mb-8 shrink-0 flex flex-col items-center relative">
          <div className="text-[72px] font-extralight leading-none tracking-tighter" style={{ textShadow: '0 2px 10px rgba(255,255,255,0.1)' }}>{speed}</div>
          <div className="text-gray-500 text-[11px] font-bold uppercase tracking-[0.2em] mt-1 opacity-70">KM/H</div>
          
          {/* Turn Signal Buttons */}
          <div className="absolute top-4 left-0 right-0 flex justify-between px-10 pointer-events-none">
            <button 
              onClick={() => setTurnSignal(prev => prev === 'left' ? 'none' : 'left')}
              className={`w-8 h-8 flex items-center justify-center rounded-full pointer-events-auto transition-colors ${turnSignal === 'left' ? 'text-orange-500 bg-orange-500/20' : 'text-gray-600 hover:text-gray-400'}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
            </button>
            <button 
              onClick={() => setTurnSignal(prev => prev === 'right' ? 'none' : 'right')}
              className={`w-8 h-8 flex items-center justify-center rounded-full pointer-events-auto transition-colors ${turnSignal === 'right' ? 'text-orange-500 bg-orange-500/20' : 'text-gray-600 hover:text-gray-400'}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 5 7 7-7 7"/><path d="M5 12h14"/></svg>
            </button>
          </div>

          <div className="flex justify-center gap-4 mt-6 text-[18px] font-semibold text-gray-600 tracking-widest cursor-pointer select-none">
             {gears.map((g) => (
                <span 
                  key={g}
                  onClick={() => {
                     setGear(g);
                     if (g === 'P') setSpeed(0);
                  }}
                  className={`transition-colors duration-200 relative z-10 px-2 py-1 ${gear === g ? 'text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]' : 'hover:text-gray-400'}`}
                >
                  {g}
                </span>
             ))}
          </div>
        </div>

        {/* Car Simulation Model */}
        <div className="relative w-full flex-1 flex justify-center items-center min-h-[260px]">
          {/* Subtle grid background */}
          <div className="absolute inset-x-0 bottom-0 h-[60%] bg-gradient-to-t from-blue-900/5 to-transparent pointer-events-none" />
          
          <div className="relative z-10 w-full flex justify-center">
             {/* Road Lane Lines */}
             <div className="absolute top-[-50px] bottom-[-50px] left-[50%] -ml-[100px] w-1 bg-gradient-to-b from-transparent via-white/20 to-transparent animate-[slide_2s_linear_infinite]" />
             <div className="absolute top-[-50px] bottom-[-50px] left-[50%] ml-[100px] w-1 bg-gradient-to-b from-transparent via-white/20 to-transparent animate-[slide_2s_linear_infinite]" />
             
             {/* Simple Car Shape representation (faster rendering than complex SVGs) */}
             <div className="relative mt-8 group cursor-pointer transition-transform duration-700 hover:scale-[1.03]">
               {/* Body */}
               <div className="w-[120px] h-[260px] bg-gradient-to-b from-[#e5e5e5] via-white to-[#d4d4d4] rounded-[45px] border-2 border-gray-300 shadow-[0_30px_60px_rgba(0,0,0,0.6),inset_0_2px_15px_rgba(255,255,255,1)] relative z-20">
                 {/* Windshield */}
                 <div className="absolute top-[30px] left-[10px] right-[10px] h-[65px] bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 rounded-t-[30px] rounded-b-md opacity-95 border-t border-white/20 shadow-inner" />
                 {/* Roof */}
                 <div className="absolute top-[95px] left-[12px] right-[12px] h-[80px] bg-gradient-to-b from-gray-50 to-gray-200 rounded-[15px]" />
                 {/* Rear Window */}
                 <div className="absolute bottom-[40px] left-[15px] right-[15px] h-[45px] bg-gradient-to-t from-gray-900 via-gray-800 to-gray-900 rounded-b-[20px] rounded-t-md opacity-95 border-b border-white/20 shadow-inner" />
                 
                 {/* Headlights (White glow) */}
                 <div className={`absolute top-2 left-4 w-5 h-2 bg-white shadow-[0_0_20px_rgba(255,255,255,0.9),0_0_40px_rgba(255,255,255,0.5)] rounded-full transition-opacity duration-300`} />
                 <div className={`absolute top-2 right-4 w-5 h-2 bg-white shadow-[0_0_20px_rgba(255,255,255,0.9),0_0_40px_rgba(255,255,255,0.5)] rounded-full transition-opacity duration-300`} />

                 {/* Turn Signals (Front) */}
                 <div className={`absolute top-[10px] left-[3px] w-[8px] h-[6px] bg-orange-500 rounded-full transition-opacity duration-200 ${turnSignal === 'left' ? 'animate-pulse opacity-100' : 'opacity-0'}`} />
                 <div className={`absolute top-[10px] right-[3px] w-[8px] h-[6px] bg-orange-500 rounded-full transition-opacity duration-200 ${turnSignal === 'right' ? 'animate-pulse opacity-100' : 'opacity-0'}`} />

                 {/* Turn Signals (Rear) */}
                 <div className={`absolute bottom-[10px] left-[3px] w-[8px] h-[6px] bg-orange-500 rounded-full transition-opacity duration-200 ${turnSignal === 'left' ? 'animate-pulse opacity-100 shadow-[0_0_10px_rgba(249,115,22,1)]' : 'opacity-0'}`} />
                 <div className={`absolute bottom-[10px] right-[3px] w-[8px] h-[6px] bg-orange-500 rounded-full transition-opacity duration-200 ${turnSignal === 'right' ? 'animate-pulse opacity-100 shadow-[0_0_10px_rgba(249,115,22,1)]' : 'opacity-0'}`} />

                 {/* Brake Lights (Red glow) - active when speed is 0 or gear is P/R */}
                 <div className={`absolute bottom-2 left-3 w-8 h-2.5 rounded-full transition-all duration-300 ${(speed === 0 || gear === 'P' || gear === 'R') ? 'bg-red-500 shadow-[0_0_25px_rgba(239,68,68,1),0_0_10px_rgba(239,68,68,0.8)]' : 'bg-red-900 shadow-[0_0_5px_rgba(239,68,68,0.4)]'}`} />
                 <div className={`absolute bottom-2 right-3 w-8 h-2.5 rounded-full transition-all duration-300 ${(speed === 0 || gear === 'P' || gear === 'R') ? 'bg-red-500 shadow-[0_0_25px_rgba(239,68,68,1),0_0_10px_rgba(239,68,68,0.8)]' : 'bg-red-900 shadow-[0_0_5px_rgba(239,68,68,0.4)]'}`} />
               </div>
               
               {/* Side Mirrors */}
               <div className="absolute top-[90px] -left-[8px] w-[10px] h-[22px] bg-gray-200 rounded-l-[8px] border border-gray-300 shadow-md z-10" />
               <div className="absolute top-[90px] -right-[8px] w-[10px] h-[22px] bg-gray-200 rounded-r-[8px] border border-gray-300 shadow-md z-10" />
             </div>
          </div>
        </div>

        {/* Driving Mode Selector */}
        <div className="w-full mt-4 mb-2 shrink-0">
          <div className="bg-[#1a1a1a] rounded-xl p-1.5 flex justify-between border border-white/5 relative">
            {/* Sliding highlight background */}
            <div 
              className="absolute top-1.5 bottom-1.5 rounded-lg bg-white/10 transition-all duration-300 ease-out border border-white/10"
              style={{
                width: 'calc(33.333% - 4px)',
                left: drivingMode === 'Chill' ? '6px' : drivingMode === 'Standard' ? 'calc(33.333% + 2px)' : 'calc(66.666% - 2px)'
              }}
            />
            
            <button 
              onClick={() => setDrivingMode('Chill')}
              className={`relative flex-1 py-2.5 z-10 flex flex-col items-center gap-1 transition-colors ${drivingMode === 'Chill' ? 'text-green-400' : 'text-gray-500 hover:text-gray-300'}`}
            >
              <Leaf className="w-4 h-4" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Chill</span>
            </button>
            <button 
              onClick={() => setDrivingMode('Standard')}
              className={`relative flex-1 py-2.5 z-10 flex flex-col items-center gap-1 transition-colors ${drivingMode === 'Standard' ? 'text-blue-400' : 'text-gray-500 hover:text-gray-300'}`}
            >
              <Zap className="w-4 h-4" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Std</span>
            </button>
            <button 
              onClick={() => setDrivingMode('Sport')}
              className={`relative flex-1 py-2.5 z-10 flex flex-col items-center gap-1 transition-colors ${drivingMode === 'Sport' ? 'text-red-500' : 'text-gray-500 hover:text-gray-300'}`}
            >
              <Gauge className="w-4 h-4" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Sport</span>
            </button>
          </div>
        </div>

        {/* Bottom Status Info */}
        <div className="mt-auto w-full grid grid-cols-2 gap-3 text-[12px] text-gray-400 shrink-0 pt-6">
          <div className="bg-[#1a1a1a] p-3.5 rounded-xl border border-white/5 flex flex-col">
            <div className="uppercase tracking-[0.1em] text-[10px] font-bold opacity-60">Autonomia</div>
            <div className="text-white text-[18px] font-medium mt-0.5 tracking-tight flex items-baseline gap-1">458 <span className="text-[11px] text-gray-500 font-normal">km</span></div>
          </div>
          <div className="bg-[#1a1a1a] p-3.5 rounded-xl border border-white/5 flex flex-col">
            <div className="uppercase tracking-[0.1em] text-[10px] font-bold opacity-60">Pneu</div>
            <div className="text-white text-[18px] font-medium mt-0.5 tracking-tight flex items-baseline gap-1">36 <span className="text-[11px] text-gray-500 font-normal">psi</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
