import React, { useState, useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap, Polyline } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Camera, AlertTriangle } from 'lucide-react';
import { useAppStore } from '../store';

// Fix for default markers in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Component to recenter map when position changes
function MapController({ center, heading, routeGeometry }: { center: L.LatLngExpression | null, heading: number | null, routeGeometry: [number, number][] | null }) {
  const map = useMap();
  
  useEffect(() => {
    if (center) {
      if (routeGeometry && routeGeometry.length > 0) {
        // If navigating, fit bounds to the route
        const bounds = L.latLngBounds(routeGeometry);
        map.fitBounds(bounds, { animate: true, padding: [50, 50] });
        
        const mapContainer = map.getContainer();
        if (mapContainer) {
          // Flatten rotation during overview for clarity
          mapContainer.style.transform = `rotateX(0deg) scale(1) rotateZ(0deg)`;
        }
      } else {
        map.setView(center, 18, { animate: true, duration: 1 });
        const mapContainer = map.getContainer();
        if (mapContainer && heading !== null) {
          mapContainer.style.transform = `rotateX(45deg) scale(1.5) rotateZ(${-heading}deg)`;
          mapContainer.style.transformOrigin = 'center center';
          mapContainer.style.transition = 'transform 1s ease-out';
        }
      }
    }
  }, [center, heading, map, routeGeometry]);
  return null;
}

const createCarIcon = (heading: number) => {
  const html = `
    <div style="transform: rotate(${heading}deg); display: flex; align-items: center; justify-content: center; width: 48px; height: 48px;">
      <div style="position: absolute; width: 48px; height: 48px; background: rgba(59, 130, 246, 0.2); border-radius: 50%; animation: ping 2s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
      <div style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; background: #2563eb; border: 2px solid white; border-radius: 50%; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
        <div style="width: 0; height: 0; border-left: 6px solid transparent; border-right: 6px solid transparent; border-bottom: 10px solid white; transform: translateY(-1px);"></div>
      </div>
    </div>
  `;
  return L.divIcon({
    html,
    className: '',
    iconSize: [48, 48],
    iconAnchor: [24, 24]
  });
};

const createIncidentIcon = (type: string, desc: string) => {
  const isRadar = type === 'radar';
  const colorClass = isRadar 
    ? 'background: rgba(239, 68, 68, 0.2); color: #ef4444; border-color: rgba(239, 68, 68, 0.5);' 
    : 'background: rgba(249, 115, 22, 0.2); color: #f97316; border-color: rgba(249, 115, 22, 0.5);';
    
  const iconSvg = isRadar 
    ? `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>`
    : `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>`;

  const html = `
    <div style="display: flex; flex-direction: column; align-items: center; pointer-events: none;">
      <div style="border-radius: 50%; border: 1px solid; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1); background-color: rgba(18, 18, 18, 0.9); backdrop-filter: blur(12px); display: flex; align-items: center; justify-content: center; width: 32px; height: 32px; padding: 4px; ${colorClass}">
        ${iconSvg}
      </div>
      <div style="margin-top: 4px; background: rgba(0,0,0,0.8); padding: 2px 8px; border-radius: 4px; font-size: 10px; color: white; font-weight: 500; white-space: nowrap; border: 1px solid rgba(255,255,255,0.1);">
        ${desc}
      </div>
    </div>
  `;
  
  return L.divIcon({
    html,
    className: '',
    iconSize: [100, 60],
    iconAnchor: [50, 30]
  });
};

function getDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371e3; // metres
  const p1 = lat1 * Math.PI/180; 
  const p2 = lat2 * Math.PI/180;
  const dp = (lat2-lat1) * Math.PI/180;
  const dl = (lon2-lon1) * Math.PI/180;

  const a = Math.sin(dp/2) * Math.sin(dp/2) +
            Math.cos(p1) * Math.cos(p2) *
            Math.sin(dl/2) * Math.sin(dl/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  return R * c;
}

export function TeslaMap({ navTarget }: { navTarget?: string | null }) {
  const [position, setPosition] = useState<{lat: number, lng: number} | null>(null);
  const [heading, setHeading] = useState<number | null>(null);
  const [initialPos, setInitialPos] = useState<{lat: number, lng: number} | null>(null);

  const routeGeometry = useAppStore(state => state.routeGeometry);
  const routeIncidents = useAppStore(state => state.routeIncidents);
  const globalIncidents = useAppStore(state => state.globalIncidents);
  const setRouteInfo = useAppStore(state => state.setRouteInfo);
  const alertDistance = useAppStore(state => state.alertDistance);
  const setActiveAlert = useAppStore(state => state.setActiveAlert);
  const activeAlert = useAppStore(state => state.activeAlert);
  const setCurrentPosition = useAppStore(state => state.setCurrentPosition);
  
  const allIncidents = [...routeIncidents, ...globalIncidents];

  // Track which incidents we have already alerted for
  const [alertedIncidentIds, setAlertedIncidentIds] = useState<Set<string>>(new Set());

  // Default fallback if no GPS
  const defLat = -23.5505;
  const defLng = -46.6333;

  useEffect(() => {
    if (position) {
      setCurrentPosition(position);
    }
  }, [position, setCurrentPosition]);

  useEffect(() => {
    if (!position || allIncidents.length === 0) return;
    
    for (const inc of allIncidents) {
       const dist = getDistance(position.lat, position.lng, inc.lat, inc.lng);
       if (dist <= alertDistance && !alertedIncidentIds.has(inc.id)) {
          // Trigger alert
          setActiveAlert(inc);
          // Auto clear alert
          setTimeout(() => setActiveAlert(null), 8000);
          
           // Try to play sound
          try {
             // We can use a browser built-in beep using audio context or SpeechSynthesis for real voice warning
             const speech = new SpeechSynthesisUtterance(`Atenção: ${inc.desc} a ${Math.round(dist)} metros`);
             speech.lang = 'pt-BR';
             speech.rate = 1.1;
             window.speechSynthesis.speak(speech);
          } catch(e){}

          setAlertedIncidentIds(prev => {
             const newSet = new Set(prev);
             newSet.add(inc.id);
             return newSet;
          });
       }
    }
  }, [position, allIncidents, alertDistance, alertedIncidentIds, setActiveAlert]);

  useEffect(() => {
    let watchId: number;
    let lastUpdate = 0;

    const startTracking = () => {
      if (!navigator.geolocation) {
         setPosition({lat: defLat, lng: defLng});
         setInitialPos({lat: defLat, lng: defLng});
         return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const newPos = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setPosition(newPos);
          setInitialPos(prev => prev || newPos);
          setHeading(pos.coords.heading || 0);
        },
        (err) => {
          console.warn(err);
          setPosition({lat: defLat, lng: defLng});
          setInitialPos({lat: defLat, lng: defLng});
        },
        { enableHighAccuracy: true }
      );
      
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const now = Date.now();
          if (now - lastUpdate < 1000) return;
          lastUpdate = now;

          const newPos = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setPosition(newPos);
          setInitialPos(prev => prev || newPos);
          setHeading(pos.coords.heading || 0);
        },
        (err) => console.warn(err),
        { enableHighAccuracy: true, maximumAge: 2000, timeout: 10000 }
      );
    };
    
    startTracking();
    return () => {
       if (navigator.geolocation) navigator.geolocation.clearWatch(watchId);
    };
  }, []);

  // Fetch Route when navTarget changes
  useEffect(() => {
    if (!navTarget || !initialPos) {
       setRouteInfo(null, null, null, []);
       return;
    }

    const fetchRoute = async () => {
      try {
        // Geocode
        let q = navTarget;
        if (q.toLowerCase() === 'casa') q = 'Avenida Paulista, São Paulo';
        if (q.toLowerCase() === 'trabalho') q = 'Parque Ibirapuera, São Paulo';
        if (!q.toLowerCase().includes('brasil') && !q.toLowerCase().includes('brazil')) {
           q += ', Brasil';
        }

        const geocodeUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&limit=1`;
        const geocodeRes = await fetch(geocodeUrl);
        const geocodeData = await geocodeRes.json();

        if (geocodeData && geocodeData.length > 0) {
           const destLat = parseFloat(geocodeData[0].lat);
           const destLng = parseFloat(geocodeData[0].lon);

           // Routing via OSRM
           const routeUrl = `https://router.project-osrm.org/route/v1/driving/${initialPos.lng},${initialPos.lat};${destLng},${destLat}?overview=full&geometries=geojson`;
           const res = await fetch(routeUrl);
           const data = await res.json();

           if (data.routes && data.routes.length > 0) {
              const route = data.routes[0];
              // GeoJSON format is [lon, lat]
              const geometry: [number, number][] = route.geometry.coordinates.map((coord: [number, number]) => [coord[1], coord[0]]);
              
              const distanceKm = (route.distance / 1000).toFixed(1);
              const durationMin = Math.ceil(route.duration / 60);

              const now = new Date();
              now.setMinutes(now.getMinutes() + durationMin);
              const etaStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

              const stats = {
                distance: `${distanceKm} km`,
                duration: `${durationMin} min`,
                eta: etaStr,
                rawDurationSec: route.duration
              };

              // Generate incidents along route
              const newIncidents: any[] = [];
              if (geometry.length > 10) {
                 const p1 = geometry[Math.floor(geometry.length * 0.3)];
                 newIncidents.push({ id: '1', type: 'radar', lat: p1[0], lng: p1[1], desc: 'Radar 60 km/h' });
                 const p2 = geometry[Math.floor(geometry.length * 0.7)];
                 newIncidents.push({ id: '2', type: 'danger', lat: p2[0], lng: p2[1], desc: 'Veículo parado' });
              }

              setRouteInfo(navTarget, geometry, stats, newIncidents);
           }
        }
      } catch (e) {
        console.error("Routing error", e);
      }
    };

    fetchRoute();
  }, [navTarget, initialPos, setRouteInfo]);

  const defaultCenter: L.LatLngExpression = position || [defLat, defLng];

  return (
    <div className="w-full h-full relative" style={{ perspective: '800px', backgroundColor: '#111' }}>
      <div className="absolute inset-0 z-0 overflow-hidden flex items-center justify-center">
        <div style={{ width: '150%', height: '150%', marginLeft: '-25%', marginTop: '-25%' }}>
            <MapContainer 
            center={defaultCenter} 
            zoom={18} 
            zoomControl={false}
            attributionControl={false}
            className="w-full h-full"
            style={{ background: '#121212' }}
            >
            <TileLayer
                url="https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}"
                maxZoom={20}
            />
            
            <MapController center={position} heading={heading} routeGeometry={routeGeometry} />

            {routeGeometry && (
              <>
                <Polyline
                  positions={routeGeometry}
                  color="#3b82f6"
                  weight={8}
                  opacity={0.8}
                  lineCap="round"
                  lineJoin="round"
                  pathOptions={{
                    className: 'animate-[pulse_2s_ease-in-out_infinite]',
                    shadowColor: '#2563eb',
                    shadowBlur: 10
                  }}
                />
                
                {/* Destination Marker */}
                <Marker 
                  position={{ 
                    lat: routeGeometry[routeGeometry.length - 1][0], 
                    lng: routeGeometry[routeGeometry.length - 1][1] 
                  }} 
                  icon={L.divIcon({
                    html: `<div style="background: #2563eb; color: white; padding: 4px 12px; border-radius: 12px; font-weight: bold; font-family: sans-serif; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4); border: 2px solid white; white-space: nowrap; transform: translate(-50%, -100%); margin-top: -10px;">${navTarget}</div>`,
                    className: '',
                    iconSize: [0, 0],
                    iconAnchor: [0, 0]
                  })}
                />
              </>
            )}

            {position && (
                <Marker 
                position={position} 
                icon={createCarIcon(0)} 
                zIndexOffset={1000}
                />
            )}

            {allIncidents.map(inc => (
                <Marker 
                key={inc.id} 
                position={{ lat: inc.lat, lng: inc.lng }} 
                icon={createIncidentIcon(inc.type, inc.desc)}
                zIndexOffset={100}
                />
            ))}
            </MapContainer>
        </div>
      </div>
      
      {/* Top subtle vignette for realistic screen depth */}
      <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-b from-black/80 to-transparent pointer-events-none z-10" />
      <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-[#111] to-transparent pointer-events-none z-10" />
    </div>
  );
}
